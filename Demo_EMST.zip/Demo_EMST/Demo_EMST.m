clc;
clear all;
close all;
%%
Input_Image=imread('D:\NITPY PhD\Contrast_EnH_Skin_Images\Source_Codes\Demo_EMST\Test_Images\50_Img.jpg');
imshow(Input_Image)
%%%Convert the input image from RGB colour space to HSV colour space%%%
HSV_Image = rgb2hsv(Input_Image);
%%%Seperate Hue, Saturation and Value Components%%%
Hue_Component=HSV_Image(:,:,1);
Saturation_Component=HSV_Image(:,:,2);
Value_Component=HSV_Image(:,:,3);
Value_Component_Double=double(Value_Component);
imshow(Value_Component_Double)
Value_Component = Value_Component_Double*255;
%%
load("EMST_Pretrained_Model.mat")
Value_Component= imresize(Value_Component,[224 224]);
Predicted_Cross_Over = abs(predict(effnet,Value_Component))
%%

Ground_Truth=imread('D:\NITPY PhD\Contrast_EnH_Skin_Images\Source_Codes\Demo_EMST\Test_Gt\50_Msk.png');
imshow(Ground_Truth)
Enhanced_Image=Sig_Tran_Cross_Over(Input_Image,20,Predicted_Cross_Over);
figure,imshow(Enhanced_Image,'Border','tight');
Enhanced_Image_Gray=rgb2gray(Enhanced_Image);
figure,imshow(Enhanced_Image_Gray,'Border','tight');

%%%Otsu's Thresholding%%%%
Threshold_Value = graythresh(Enhanced_Image_Gray);
% %%%The function gives normalized Threshold%%%
Threshold_Value=Threshold_Value*255;
Segmented_Output=Enhanced_Image_Gray<Threshold_Value;
figure,imshow(Segmented_Output,'Border','tight');
DSI_Otsu = dice(Segmented_Output,Ground_Truth)